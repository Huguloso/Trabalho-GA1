#include "pch.h"
#include "Npc.h"


Npc::Npc()
{
}


Npc::~Npc()
{
}
