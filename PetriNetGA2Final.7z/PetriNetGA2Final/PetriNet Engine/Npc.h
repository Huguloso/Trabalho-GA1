#pragma once
#include "Token.h"
class Npc : public Token {
public:
	Npc();
	~Npc();
};

